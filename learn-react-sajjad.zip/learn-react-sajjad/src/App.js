import Header from './compounents/Header'
import Section from './compounents/section1';
import Section2 from './compounents/section2';
import Footer from './compounents/footer';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
function App() {
  return (
    <div className="App">
      <header className="App-header">
     
        <Header/>
        <Section/>
        <Section2/>
        <Footer/>

        
      </header>
    </div>
  );
}

export default App;
