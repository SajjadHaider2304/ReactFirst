function Footer() {

    return (
        <center>
            <h1>Join Us</h1>
            <div className="container">
                <div class="row">
                    <div className="col-6 mx-auto">
                        <form action="">
                            <input className="form-control" type="text" placeholder="name" /> <br /><br />
                            <input className="form-control" type="text" placeholder="address" /><br /><br />
                            <input className="form-control" type="text" placeholder="CITY" /><br /><br />
                            <input className="form-control" type="text" placeholder="STATE" /><br /><br />
                            <select name="" id="">
                                <option value="">NewsWeek</option>
                                <option value="">Iran</option>
                                <option value="">UAE</option>
                            </select><br /><br />
                            <input   type="radio" name="year" id="" />
                            <label for="">1 Year</label>
                            <input   type="radio" name="year" id="" />
                            <label for="">2 Year</label>
                            <br />
                            <textarea name="" id="" cols="40" rows="10" placeholder="Comment"></textarea>
                            <div>
                                <a type="submit" name="" id="" class="btn btn-primary" href="#" role="button">Submit</a>

                            </div>
                        </form>



                    </div>
                </div>

            </div>

            <br />
            <br />
        </center>

    );


}

export default Footer;