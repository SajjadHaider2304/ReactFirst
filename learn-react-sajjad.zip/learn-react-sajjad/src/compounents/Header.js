import "./header.css"
import haider from "../assets/top.png"
import instagram from "../assets/instagram.jpg"
import twitter from "../assets/twiter.png"
import facebook from "../assets/facebook.png"
function Header() {

    return (
        <div className="container-fluid">

            <img src={haider} className="image" alt="sajjad haidersajjadhaider" />
            <table width="100%">
                <tr>
                    <th>
                        <h2>Ara Profile</h2>

                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis dolores nostrum corporis consequatur
                            illo libero quod, dolor pariatur eius culpa aliquam qui vel officiis
                            accusantium quas provident magnam quis amet! Lorem ipsum dolor sit amet consectetur, adipisicing
                            elit. A sint corporis voluptate, mollitia aperiam maiores quidem ut asperiores
                            ea doloremque.
                        </p>
                    </th>
                    <th>




                    </th>
                    <th>
                        <img src={instagram} alt="sajjad haider" />
                        <img src={twitter} alt="sajjad haider" />
                        <img src={facebook} width="30px" height="30px" alt="sajjad haider" />
                        <br />
                        <a href="fb.com/naveed.trainer">fb.com/naveed.trainer</a>
                    </th>
                </tr>

            </table>


        </div>

    )
}

export default Header;