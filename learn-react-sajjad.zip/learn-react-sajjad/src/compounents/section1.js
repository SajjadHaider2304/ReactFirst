import roll from "../assets/roll.jpg"
import clothroll from "../assets/clothroll.jpg"



function Section() {
    return(
        <table width="100%">
        <tr>
            <td>
                <img src={roll} width="400px" alt=""/>
            </td>
            <td>
                <h1>Cable Tray</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, dolorem iste voluptatibus
                    consectetur repellat alias dignissimos pariatur ducimus corrupti esse consequatur error molestiae
                    at? Qui illo aperiam
                    provident tempore reprehenderit.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, dolorem iste voluptatibus
                    consectetur repellat alias dignissimos pariatur ducimus corrupti esse consequatur error molestiae
                    at? Qui illo aperiam
                    provident tempore reprehenderit.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, dolorem iste voluptatibus
                    consectetur repellat alias dignissimos pariatur ducimus corrupti esse consequatur error molestiae
                    at? Qui illo aperiam
                    provident tempore reprehenderit.</p>
            </td>
            <td>
                <img src={clothroll} width="300px" alt=""/>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis quaerat quod voluptates porro
                    nisi ullam quia optio quam iure officiis <br/> modi,
                    autem architecto accusantium dolor, voluptate minima maxime est praesentium!
                </p>
            </td>

        </tr>
    </table>
    );
    
}
export default Section;