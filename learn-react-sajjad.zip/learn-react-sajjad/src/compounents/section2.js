function Section2() {


    return (
        <table width="100%">
            <tr>
                <td>
                    <ul>
                        <li>Ara</li>
                        <li>Profile</li>
                        <li>Sheet </li>
                        <li>170*</li>
                    </ul>
                </td>
                <td>
                    <ul>
                        <li>Ara</li>
                        <li>Profile</li>
                        <li>Sheet </li>
                        <li>170*</li>
                    </ul>
                </td>
                <td>
                    <ol>
                        <li>Ara</li>
                        <li>Profile</li>
                        <li>Sheet </li>
                        <li>170*</li>
                    </ol>
                </td>
            </tr>
        </table>


    );

}
export default Section2;